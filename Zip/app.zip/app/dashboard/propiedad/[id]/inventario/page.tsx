// 📁 src/app/dashboard/propiedad/[id]/inventario/page.tsx
'use client';

import { useParams, useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase/client';
import TopBar from '@/components/ui/topbar';
import Loading from '@/components/ui/loading';
import EmptyState from '@/components/ui/emptystate';
import EditItemModal from './components/EditItemModal';

interface InventoryItem {
  id: string;
  object_name: string;
  confidence: number;
  space_type: string | null;
  labels: string | null;
  image_url: string;
  image_id: string;
  created_at: string;
}

interface PropertyData {
  id: string;
  nombre: string;
  tipo_propiedad: string;
}

interface SpaceData {
  id: string;
  nombre: string;
}

export default function InventarioPage() {
  const params = useParams();
  const router = useRouter();
  const propertyId = params.id as string;

  const [user, setUser] = useState<any>(null);
  const [property, setProperty] = useState<PropertyData | null>(null);
  const [spaces, setSpaces] = useState<SpaceData[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSpace, setFilterSpace] = useState<string>('all');
  
  // Estados para el modal de edición
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  useEffect(() => {
    checkUser();
  }, [propertyId]);

  const checkUser = async () => {
    const { data: { user: authUser } } = await supabase.auth.getUser();
    if (!authUser) { 
      router.push('/login'); 
      return; 
    }
    const { data: profile } = await supabase.from('profiles').select('*').eq('id', authUser.id).single();
    setUser({ ...profile, id: authUser.id });
    loadData();
  };

  const loadData = async () => {
    try {
      setLoading(true);

      // Cargar propiedad
      const { data: propertyData, error: propError } = await supabase
        .from('propiedades')
        .select('id, nombre, tipo_propiedad')
        .eq('id', propertyId)
        .single();

      if (propError) throw propError;
      setProperty(propertyData);

      // Cargar espacios de la propiedad
      const { data: spacesData } = await supabase
        .from('property_spaces')
        .select('id, nombre')
        .eq('property_id', propertyId)
        .order('nombre');
      
      setSpaces(spacesData || []);

      // Cargar inventario
      await loadInventory();

    } catch (error) {
      console.error('❌ Error cargando datos:', error);
      alert('Error al cargar la propiedad');
    } finally {
      setLoading(false);
    }
  };

  const loadInventory = async () => {
    try {
      const { data, error } = await supabase
        .from('property_inventory')
        .select('*')
        .eq('property_id', propertyId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setInventory(data || []);
    } catch (error) {
      console.error('❌ Error cargando inventario:', error);
    }
  };

  const handleAnalyzeAll = async () => {
    if (!confirm('¿Analizar todas las fotos de la galería? Esto puede tomar varios minutos.')) {
      return;
    }

    try {
      setAnalyzing(true);

      const response = await fetch('/api/vision/analyze', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId })
      });

      const result = await response.json();

      if (result.success) {
        alert(`✅ ${result.message}`);
        await loadInventory();
      } else {
        throw new Error(result.error);
      }

    } catch (error) {
      console.error('❌ Error en análisis:', error);
      alert('Error al analizar imágenes');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleEditItem = (item: InventoryItem) => {
    setEditingItem(item);
    setShowEditModal(true);
  };

  const handleSaveEdit = async (updatedItem: { object_name: string; labels: string; space_type: string }) => {
    if (!editingItem) return;

    try {
      const { error } = await supabase
        .from('property_inventory')
        .update({
          object_name: updatedItem.object_name,
          labels: updatedItem.labels || null,
          space_type: updatedItem.space_type || null
        })
        .eq('id', editingItem.id);

      if (error) throw error;

      await loadInventory();
      setShowEditModal(false);
      setEditingItem(null);
      alert('✅ Item actualizado');
    } catch (error) {
      console.error('❌ Error actualizando item:', error);
      alert('Error al actualizar');
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    if (!confirm('¿Eliminar este item del inventario?')) return;

    try {
      const { error } = await supabase
        .from('property_inventory')
        .delete()
        .eq('id', itemId);

      if (error) throw error;

      setInventory(inventory.filter(item => item.id !== itemId));
      alert('✅ Item eliminado');
    } catch (error) {
      console.error('❌ Error eliminando item:', error);
      alert('Error al eliminar');
    }
  };

  const handleClearAll = async () => {
    if (!confirm('⚠️ ¿Eliminar TODO el inventario de esta propiedad? Esta acción no se puede deshacer.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('property_inventory')
        .delete()
        .eq('property_id', propertyId);

      if (error) throw error;

      setInventory([]);
      alert('✅ Inventario limpiado');
    } catch (error) {
      console.error('❌ Error limpiando inventario:', error);
      alert('Error al limpiar inventario');
    }
  };

  const handleLogout = async () => {
    if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
      await supabase.auth.signOut();
      router.push('/login');
    }
  };

  // Obtener nombre del espacio por ID
  const getSpaceName = (spaceId: string | null) => {
    if (!spaceId) return 'Sin espacio';
    const space = spaces.find(s => s.id === spaceId);
    return space?.nombre || spaceId.slice(0, 8) + '...';
  };

  // Obtener espacios únicos del inventario
  const uniqueSpaces = Array.from(
    new Set(inventory.map(item => item.space_type).filter(Boolean))
  ) as string[];

  // Filtrar inventario
  const filteredInventory = inventory.filter(item => {
    const matchSearch = !searchQuery || 
      item.object_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.labels && item.labels.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchSpace = filterSpace === 'all' || 
      (filterSpace === 'sin-espacio' && !item.space_type) ||
      item.space_type === filterSpace;

    return matchSearch && matchSpace;
  });

  if (loading) {
    return <Loading message="Cargando inventario..." />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-ras-crema via-white to-ras-crema">
      <TopBar 
        title={`Inventario - ${property?.nombre || ''}`}
        showBackButton={true}
        showUserInfo={true}
        userEmail={user?.email}
        onLogout={handleLogout}
      />

      <main className="max-w-5xl mx-auto px-4 py-8">
        {/* Estadística simple */}
        {inventory.length > 0 && (
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">Total de Items</h3>
                <p className="text-4xl font-bold text-ras-azul">{inventory.length}</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={handleAnalyzeAll}
                  disabled={analyzing}
                  className="px-6 py-3 bg-gradient-to-r from-ras-azul to-ras-turquesa text-white rounded-xl hover:shadow-xl transition-all disabled:bg-gray-400 font-semibold"
                >
                  {analyzing ? 'Analizando...' : '🔍 Analizar Galería'}
                </button>
                {inventory.length > 0 && (
                  <button
                    onClick={handleClearAll}
                    className="px-6 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all font-semibold"
                  >
                    Limpiar Todo
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Barra de búsqueda y filtros */}
        <div className="bg-white rounded-2xl shadow-lg border-2 border-gray-300 p-4 mb-6">
          <div className="flex items-center gap-4">
            {/* Buscador */}
            <div className="flex-1">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Buscar por objeto o etiquetas..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border-2 border-gray-200 rounded-lg focus:border-ras-turquesa focus:outline-none transition-colors"
                />
                <svg className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8"/>
                  <path d="m21 21-4.35-4.35"/>
                </svg>
              </div>
            </div>

            {/* Filtro por espacio */}
            <div className="relative">
              <select
                value={filterSpace}
                onChange={(e) => setFilterSpace(e.target.value)}
                className="appearance-none bg-white border-2 border-gray-200 rounded-lg px-4 py-2 pr-10 font-medium text-gray-700 hover:border-ras-turquesa focus:border-ras-turquesa focus:outline-none transition-colors cursor-pointer"
              >
                <option value="all">📍 Todos los espacios</option>
                <option value="sin-espacio">🔹 Sin espacio</option>
                {uniqueSpaces.map(spaceId => (
                  <option key={spaceId} value={spaceId}>
                    {getSpaceName(spaceId)}
                  </option>
                ))}
              </select>
              <svg className="w-4 h-4 text-gray-500 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </div>
          </div>
        </div>

        {/* Tabla de inventario */}
        {filteredInventory.length > 0 ? (
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
            {/* Encabezados */}
            <div className="bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200 px-6 py-3">
              <div className="grid grid-cols-12 gap-4 items-center text-sm font-semibold text-gray-600">
                <div className="col-span-1">Imagen</div>
                <div className="col-span-3">Objeto</div>
                <div className="col-span-3">Etiquetas</div>
                <div className="col-span-3">Espacio</div>
                <div className="col-span-2 text-center">Acciones</div>
              </div>
            </div>

            {/* Filas */}
            <div className="divide-y divide-gray-100">
              {filteredInventory.map((item) => (
                <div key={item.id} className="px-6 py-4 hover:bg-gray-50 transition-all">
                  <div className="grid grid-cols-12 gap-4 items-center">
                    {/* Imagen */}
                    <div className="col-span-1">
                      <img
                        src={item.image_url}
                        alt={item.object_name}
                        className="w-16 h-16 object-cover rounded-lg border-2 border-gray-200"
                      />
                    </div>

                    {/* Objeto */}
                    <div className="col-span-3">
                      <div className="text-sm font-medium text-gray-900">
                        {item.object_name}
                      </div>
                    </div>

                    {/* Etiquetas */}
                    <div className="col-span-3">
                      {item.labels ? (
                        <div className="flex flex-wrap gap-1">
                          {item.labels.split(',').slice(0, 3).map((label, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-1 text-xs rounded-lg bg-purple-100 text-purple-700 font-medium"
                            >
                              {label.trim()}
                            </span>
                          ))}
                          {item.labels.split(',').length > 3 && (
                            <span className="px-2 py-1 text-xs rounded-lg bg-gray-100 text-gray-600">
                              +{item.labels.split(',').length - 3}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-sm text-gray-400">Sin etiquetas</span>
                      )}
                    </div>

                    {/* Espacio */}
                    <div className="col-span-3">
                      <span className="px-3 py-1 text-sm rounded-lg bg-blue-100 text-blue-700 font-medium">
                        {getSpaceName(item.space_type)}
                      </span>
                    </div>

                    {/* Acciones */}
                    <div className="col-span-2">
                      <div className="flex gap-2 justify-center">
                        {/* Editar */}
                        <button
                          onClick={() => handleEditItem(item)}
                          className="w-10 h-10 rounded-lg border-2 border-blue-200 bg-blue-50 hover:bg-blue-100 hover:border-blue-400 hover:scale-110 transition-all flex items-center justify-center group"
                          title="Editar"
                        >
                          <svg className="w-5 h-5 text-blue-600 group-hover:scale-110 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                          </svg>
                        </button>

                        {/* Eliminar */}
                        <button
                          onClick={() => handleDeleteItem(item.id)}
                          className="w-10 h-10 rounded-lg border-2 border-red-200 bg-red-50 hover:bg-red-100 hover:border-red-400 hover:scale-110 transition-all flex items-center justify-center group"
                          title="Eliminar"
                        >
                          <svg className="w-5 h-5 text-red-600 group-hover:scale-110 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <line x1="18" y1="6" x2="6" y2="18"/>
                            <line x1="6" y1="6" x2="18" y2="18"/>
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <EmptyState 
            icon={
              <svg className="w-12 h-12 text-amber-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
                <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
                <line x1="12" y1="22.08" x2="12" y2="12"/>
              </svg>
            }
            title={inventory.length === 0 ? "No hay items en el inventario" : "No se encontraron resultados"}
            description={inventory.length === 0 ? "Haz clic en 'Analizar Galería' para detectar objetos automáticamente" : "Intenta con otra búsqueda o cambia los filtros"}
            actionLabel={inventory.length === 0 ? "🔍 Analizar Galería" : undefined}
            onAction={inventory.length === 0 ? handleAnalyzeAll : undefined}
          />
        )}
      </main>

      {/* Modal de edición */}
      {showEditModal && editingItem && (
        <EditItemModal
          item={editingItem}
          spaces={spaces}
          onClose={() => {
            setShowEditModal(false);
            setEditingItem(null);
          }}
          onSave={handleSaveEdit}
        />
      )}
    </div>
  );
}